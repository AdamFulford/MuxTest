#ifndef MUXTEST_H
#define MUXTEST_H

//#include "daisysp.h"
#include "daisy_seed.h"

//using namespace daisysp;
using namespace daisy;

static DaisySeed hw;

#endif